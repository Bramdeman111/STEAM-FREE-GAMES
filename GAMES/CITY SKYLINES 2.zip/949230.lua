-- 949230's Lua and Manifest Created by Morrenus
-- Cities: Skylines II
-- Created: December 10, 2025 at 06:04:30 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 18
-- Total DLCs: 24
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(949230) -- Cities: Skylines II
-- MAIN APP DEPOTS
addappid(949231, 1, "eadf0796a624164bd8838fc14a95bd34b9c41e87048bbb4a23b86f0b77c1fb67") -- Depot 949231
setManifestid(949231, "3091432119205282628", 77780678061)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Cities Skylines II - Creator Pack Modern Architecture (AppID: 2427741)
addappid(2427741)
addappid(2427741, 1, "d2166f8c2e87ec7b0900a190c9cc19ee010fdd65fd616e23a0f5e7c86ab7f6b4") -- Cities Skylines II - Creator Pack Modern Architecture - Depot 2427741
setManifestid(2427741, "438974973343020455", 746348284)
-- Cities Skylines II - Creator Pack Urban Promenades (AppID: 2427742)
addappid(2427742)
addappid(2427742, 1, "10f591eaa4714450e076677b7e7769008213ced4a34ee7d8680ab9e56ef4fe49") -- Cities Skylines II - Creator Pack Urban Promenades - Depot 2427742
setManifestid(2427742, "7552307450690748413", 1531786532)
-- Cities Skylines II - Bridges  Ports (AppID: 2427743)
addappid(2427743)
addappid(2427743, 1, "b69c0f20602c6d566bb0b1fc34738968384c495c701d6c514a95eb71d13b0a2b") -- Cities Skylines II - Bridges  Ports - Depot 2427743
setManifestid(2427743, "4116766632511709907", 7384423882)
-- Cities Skylines II - Soft Rock Radio (AppID: 2427745)
addappid(2427745)
addappid(2427745, 1, "3ab8a19fe1ec5a750b6a807a30203880c99504c321500a7e64e18c361e7cce0f") -- Cities Skylines II - Soft Rock Radio - Depot 2427745
setManifestid(2427745, "3710823592724179000", 198315651)
-- Cities Skylines II - Cold Wave Channel (AppID: 2427746)
addappid(2427746)
addappid(2427746, 1, "0942886d7a2f91351b71e76ac8bb8f6f6aa4379ded6936690fb219345679a50b") -- Cities Skylines II - Cold Wave Channel - Depot 2427746
setManifestid(2427746, "3599726097608043890", 218189928)
-- Cities Skylines II - Creator Pack Mediterranean Heritage  (AppID: 2945610)
addappid(2945610)
addappid(2945610, 1, "bbe5da829bb0f945cca502394f4e116a571e24dc9d17942e537ba40cca9e5edd") -- Cities Skylines II - Creator Pack Mediterranean Heritage  - Depot 2945610
setManifestid(2945610, "2993533374734752647", 2035532506)
-- Cities Skylines II - Creator Pack Leisure Venues (AppID: 2945630)
addappid(2945630)
addappid(2945630, 1, "948d67b9b3f9a86527dbc70fb2c69ddb3163cbba5f848c838a600ba5c1ab760f") -- Cities Skylines II - Creator Pack Leisure Venues - Depot 2945630
setManifestid(2945630, "2449260315622315362", 1536686015)
-- Cities Skylines II - Creator Pack Dragon Gate (AppID: 2945640)
addappid(2945640)
addappid(2945640, 1, "e1c2ffe0f3139d1e9dcce3914e56e42316024a30f289013e5b0a76181bf18325") -- Cities Skylines II - Creator Pack Dragon Gate - Depot 2945640
setManifestid(2945640, "8533092457037685235", 1313024833)
-- Cities Skylines II - Jade Road Radio (AppID: 3054840)
addappid(3054840)
addappid(3054840, 1, "02aead37a548fa148998bd2698389d9b497ba84680d8a1ca3116bb3c79208415") -- Cities Skylines II - Jade Road Radio - Depot 3054840
setManifestid(3054840, "4418427781040991518", 209973053)
-- Cities Skylines II - Feelgood Funk Radio (AppID: 3055040)
addappid(3055040)
addappid(3055040, 1, "3b44a007515e566327cfc4ed209b8c71ffe4789a4a12fe3659caae3bf23440d3") -- Cities Skylines II - Feelgood Funk Radio - Depot 3055040
setManifestid(3055040, "1717807990026297671", 200124367)
-- Cities Skylines II - Atmospheric Piano Channel (AppID: 3055080)
addappid(3055080)
addappid(3055080, 1, "e39253ba495db02d1cb4cd69a6b9a7aba7b0d9439b2ee13cea0d153364b73267") -- Cities Skylines II - Atmospheric Piano Channel - Depot 3055080
setManifestid(3055080, "7368325153196266226", 227637903)
-- Cities Skylines II - Creator Pack Supply Chains (AppID: 3579760)
addappid(3579760)
addappid(3579760, 1, "e2d84887eb4a063ad947d4415584043d4f5e19246605264ede10f1381feeaef7") -- Cities Skylines II - Creator Pack Supply Chains - Depot 3579760
setManifestid(3579760, "2124768731922674455", 1195564322)
-- Cities Skylines II - Creator Pack Skyscrapers (AppID: 3579790)
addappid(3579790)
addappid(3579790, 1, "fb3b8ff0129675b1fe8d56df96c57967abd116ed3a9493c3aa9198fd48872e7e") -- Cities Skylines II - Creator Pack Skyscrapers - Depot 3579790
setManifestid(3579790, "7888914529593234115", 962377141)
-- Cities Skylines II - Synth  Steel Radio (AppID: 3579800)
addappid(3579800)
addappid(3579800, 1, "6f9f1c7e0ed9f74492f3e3ee9d52d48e9e5fe3b9164e4eb5d728603b34cc23da") -- Cities Skylines II - Synth  Steel Radio - Depot 3579800
setManifestid(3579800, "1296127626803180328", 182778301)
-- Cities Skylines II - Cloud Lounge FM (AppID: 3579810)
addappid(3579810)
addappid(3579810, 1, "8c30a42cd78c0000dac3bec7719e272506de74f660f54a8af7c88fd46666f8e1") -- Cities Skylines II - Cloud Lounge FM - Depot 3579810
setManifestid(3579810, "7298211655948922027", 196273963)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2427730) -- Cities Skylines II - San Francisco Set
addappid(2427731) -- Cities Skylines II - Landmark Buildings
addappid(2427740) -- Cities Skylines II - Beach Properties
addappid(2427744) -- Cities Skylines II - Deluxe Relax Station
addappid(2887600) -- Cities Skylines II - Beach Properties Bundle
addappid(3350700) -- Cities Skylines II - Modern City Bundle
addappid(3535990) -- Cities Skylines II - Leisure  Legacy Bundle
addappid(3740440) -- Cities Skylines II - Bridges  Ports Bundle
addappid(4156790) -- Cities Skylines II - Skyscrapers  Supply Chains Bundle