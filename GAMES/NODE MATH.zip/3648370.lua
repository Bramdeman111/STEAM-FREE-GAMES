-- 3648370's Lua and Manifest Created by Morrenus
-- Node Math
-- Created: January 17, 2026 at 08:16:02 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3648370) -- Node Math
-- MAIN APP DEPOTS
addappid(3648371, 1, "24507e6fe30f405510ace723b1ea1b62a8b0c0b8758cdea4166ab585476a2435") -- Depot 3648371
setManifestid(3648371, "4642313402668939905", 584160497)