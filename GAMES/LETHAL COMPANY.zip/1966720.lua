-- 1966720's Lua and Manifest Created by Morrenus
-- Lethal Company
-- Created: October 06, 2025 at 05:28:13 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1966720) -- Lethal Company
-- MAIN APP DEPOTS
addappid(1966721, 1, "b79233b678dae6d3f928ff9c6c7674d559427776a1337dee238773a4fec60949") -- Depot 1966721
setManifestid(1966721, "1749099131234587692", 1462179609)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)