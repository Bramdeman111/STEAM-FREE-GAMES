-- 3405340's Lua and Manifest Created by Morrenus
-- Megabonk
-- Created: December 25, 2025 at 08:58:23 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3405340) -- Megabonk
-- MAIN APP DEPOTS
addappid(3405342, 1, "0fbab2971279bba685debbfa503e2da7e014fb5066cec822fcda80f9465e304e") -- Depot 3405342
setManifestid(3405342, "769452950908277218", 513927502)
addappid(3405341, 1, "d9a92d0ab707134e1d6d8a7f6f5c3e1211d295e888e3cf780efbf560d4e15c4e") -- Depot 3405341
setManifestid(3405341, "2430866723140980377", 557483201)