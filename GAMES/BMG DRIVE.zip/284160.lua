-- 284160's Lua and Manifest Created by Morrenus
-- BeamNG.drive
-- Created: December 16, 2025 at 14:55:55 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(284160, 1, "10c614fbabbde67d0375ae04f35cbc597f9f49f6addbe766465e77ba7cb4a9bb") -- BeamNG.drive
-- MAIN APP DEPOTS
addappid(284161, 1, "0e77f1cd7bb3169d9885cc26c7d2ef9fffc02c8c49671bec7b7308dd6cf86229") -- BeamNG.drive Windows
setManifestid(284161, "1614918757665408036", 51369294514)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)