-- 3527290's Lua and Manifest Created by Morrenus
-- PEAK
-- Branch: PUBLIC
-- Created: January 06, 2026 at 14:35:43 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3527290, 1, "499eb049b24a30730d5926e9cf72bfa9237d1a7f6de06e94a05e9c2c01348478") -- PEAK
-- MAIN APP DEPOTS
addappid(3527291, 1, "f55585bb6a00ba332421256f80ba05e27afc38fec6170b9a763138244c506f05") -- Depot 3527291
setManifestid(3527291, "7708056371179821933", 7759469489)