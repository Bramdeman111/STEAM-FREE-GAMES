-- 1445790's Lua and Manifest Created by Morrenus
-- Make Way
-- Created: November 03, 2025 at 17:28:37 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1445790) -- Make Way
-- MAIN APP DEPOTS
addappid(1445791, 1, "443955ed94898f46baf7dffc42b6771e7c8992f09619b9d62b22630a6693a721") -- Depot 1445791
setManifestid(1445791, "7073136019082694464", 1144477368)