-- 648800's Lua and Manifest Created by Morrenus
-- Raft
-- Created: September 30, 2025 at 08:55:45 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(648800) -- Raft
-- MAIN APP DEPOTS
addappid(648801, 1, "69b674ffb72cbe77ce081b29070056279accc29956cad5d38d31e0d3e2090632") -- Raft Content
setManifestid(648801, "577422474383592005", 7116122279)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)