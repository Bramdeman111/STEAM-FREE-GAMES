-- 227300's Lua and Manifest Created by Morrenus
-- Euro Truck Simulator 2
-- Created: December 15, 2025 at 07:45:15 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 107
-- Total DLCs: 101 (4 excluded)

-- MAIN APPLICATION
addappid(227300, 1, "4efc6eb3aea74680b954e5b88327ec42ef52984cb390f9dc905aab42a4ae6652") -- Euro Truck Simulator 2
-- MAIN APP DEPOTS
addappid(227301, 1, "1baf18f6181ad3f9ce663dab07f93ba0f3f5194c82b64785e4cd9f63f3a56b28") -- Euro Truck Simulator 2 - Content
setManifestid(227301, "6665074982123510237", 37059666497)
addappid(227302, 1, "edfb6f81d8ec91175145051344fdf788840b2235df88cca912a7602de47f54af") -- Euro Truck Simulator 2 - Windows
setManifestid(227302, "5477761985776227335", 57931848)
addappid(227303, 1, "f764a1a949001dd100176a10f3f0b50531c353122118ba0e41bea9eaafb0437f") -- Euro Truck Simulator 2 - GNU/Linux
setManifestid(227303, "8615062910043166656", 53309744)
addappid(227304, 1, "32ab4f23d2cb9a8cb610b299d0012509d1b2b64dc694616d8a8c711a2d605057") -- Euro Truck Simulator 2 - macOS
setManifestid(227304, "2210278723577698661", 65217178)
addappid(388473, 1, "22cd4aa20d6c0e57938157b6ad3001ebb15b2b82ed99ee59b7beeda3d720d358") -- Euro Truck Simulator 2 - PC Gamer DLC (388473) Depot
setManifestid(388473, "7958922419590227872", 0)
addappid(388478, 1, "37e441d79e75d5e2fc7af4075ea3afbb4309ce05a27fc63f81419867ee29cc84") -- Euro Truck Simulator 2 - Rocket League Promo (388478) Depot
setManifestid(388478, "614205605403850615", 0)
-- DLCS WITH DEDICATED DEPOTS
-- Euro Truck Simulator 2 - Going East (AppID: 227310)
addappid(227310)
addappid(227310, 1, "b06666dc044784f4331b6572132630cb7b36fd1c83688aa215f808fc8460729d") -- Euro Truck Simulator 2 - Going East - Euro Truck Simulator 2 - Going East! (227310) Depot
setManifestid(227310, "29252533301610345", 37816690)
-- Euro Truck Simulator 2 - Halloween Paint Jobs Pack (AppID: 258460)
addappid(258460)
addappid(258460, 1, "a3f49706464f613855bdb86f4aa8ad16370390f18c059398495dbd76e22bae01") -- Euro Truck Simulator 2 - Halloween Paint Jobs Pack - Euro Truck Simulator 2 - Halloween Paint Jobs DLC (258460) Depot
setManifestid(258460, "7921356351300426751", 0)
-- Euro Truck Simulator 2 - Ice Cold Paint Jobs Pack (AppID: 266930)
addappid(266930)
addappid(266930, 1, "f4d470f5465831a9dd38238f63c9cb1dc198f2c71fbfd95ec811c3d536083afb") -- Euro Truck Simulator 2 - Ice Cold Paint Jobs Pack - Euro Truck Simulator 2 - Ice Cold Paint Jobs DLC (266930) Depot
setManifestid(266930, "3283532009505007756", 0)
-- Euro Truck Simulator 2 - Prehistoric Paint Jobs Pack (AppID: 266931)
addappid(266931)
addappid(266931, 1, "e7e3ea706608c68f2c98adad6195b9e99224b03a061dab06708283110249b71e") -- Euro Truck Simulator 2 - Prehistoric Paint Jobs Pack - Euro Truck Simulator 2 - Prehistoric Paint Jobs Pack (266931) Depot
setManifestid(266931, "4309460561061129218", 0)
-- Euro Truck Simulator 2 - Force of Nature Paint Jobs Pack (AppID: 292320)
addappid(292320)
addappid(292320, 1, "90f9db92d02b768332a169e698883316b4f8390294a000dbb728bf8db4bb6ea6") -- Euro Truck Simulator 2 - Force of Nature Paint Jobs Pack - Euro Truck Simulator 2 - Force of Nature Paint Jobs DLC (292320) Depot
setManifestid(292320, "6527425934994182475", 0)
-- Euro Truck Simulator 2 - Metallic Paint Jobs Pack (AppID: 297790)
addappid(297790)
addappid(297790, 1, "0233fe7dd02c1e88ba24e3f1d37532b77a850bf9ab456d7ebc6277b8a40360ef") -- Euro Truck Simulator 2 - Metallic Paint Jobs Pack - Euro Truck Simulator 2 - Metallic Paint Jobs DLC (297790) Depot
setManifestid(297790, "8979825731496411430", 0)
-- Euro Truck Simulator 2 - UK Paint Jobs Pack (AppID: 297791)
addappid(297791)
addappid(297791, 1, "59ec65b036441b6041336c12e035f557aa24ec9a76339b833b97eea3bc599f5f") -- Euro Truck Simulator 2 - UK Paint Jobs Pack - Euro Truck Simulator 2 - UK Paint Jobs DLC (297791) Depot
setManifestid(297791, "7907072597469392319", 0)
-- Euro Truck Simulator 2 - Irish Paint Jobs Pack (AppID: 297792)
addappid(297792)
addappid(297792, 1, "bdfd47562c2dbc16d82fd2874062d5ec0719c39f0e4651a024750b36efb56aeb") -- Euro Truck Simulator 2 - Irish Paint Jobs Pack - Euro Truck Simulator 2 - Irish Paint Jobs DLC (297792) Depot
setManifestid(297792, "2957245413978440635", 0)
-- Euro Truck Simulator 2 - Scottish Paint Jobs Pack (AppID: 297793)
addappid(297793)
addappid(297793, 1, "6884199428ed7ac5db8a1c7fce8fff2dfe0b9c64f83bc5e2c5983a055e7b31a3") -- Euro Truck Simulator 2 - Scottish Paint Jobs Pack - Euro Truck Simulator 2 - Scottish Paint Jobs DLC (297793) Depot
setManifestid(297793, "2905133123341935477", 0)
-- Euro Truck Simulator 2 - Flip Paint Designs (AppID: 301180)
addappid(301180)
addappid(301180, 1, "1392869053d38e8512ccf586fafc2dcf914a4a7e5eb73c11b4ce7a5f0dbc19a6") -- Euro Truck Simulator 2 - Flip Paint Designs - Euro Truck Simulator 2 - Flip Paint Designs DLC (301180) Depot
setManifestid(301180, "380357946844704080", 0)
-- Euro Truck Simulator 2 - Polish Paint Jobs Pack (AppID: 304020)
addappid(304020)
addappid(304020, 1, "da29a5daa49c3470f56dd4cac21ad1ad4e1b4a3fa9c9d0ba84936ec1b14f81ec") -- Euro Truck Simulator 2 - Polish Paint Jobs Pack - Euro Truck Simulator 2 - Polish Paint Jobs Pack (304020) Depot
setManifestid(304020, "7623190349550009080", 0)
-- Euro Truck Simulator 2 - Brazilian Paint Jobs Pack (AppID: 304140)
addappid(304140)
addappid(304140, 1, "3eda1b6792cc2682797d1c86e5d38cb50fa601d5f2f62d367ab00b03254e23a9") -- Euro Truck Simulator 2 - Brazilian Paint Jobs Pack - Euro Truck Simulator 2 - Brazilian Paint Jobs Pack (304140) Depot
setManifestid(304140, "8467607110335293908", 0)
-- Euro Truck Simulator 2 - Fantasy Paint Jobs Pack (AppID: 304210)
addappid(304210)
addappid(304210, 1, "ca10ce279520e0e9a9d898a436497106b4dbb5afd82e990c56309ea5f6ea7f16") -- Euro Truck Simulator 2 - Fantasy Paint Jobs Pack - Euro Truck Simulator 2 - Fantasy Paint Jobs Pack (304210) Depot
setManifestid(304210, "4860658739016211282", 0)
-- Euro Truck Simulator 2 - USA Paint Jobs Pack (AppID: 304211)
addappid(304211)
addappid(304211, 1, "0aca8cf58b08cbc0381262d0e6ba19d5dccb4aebd904243553cb8fab44358890") -- Euro Truck Simulator 2 - USA Paint Jobs Pack - Euro Truck Simulator 2 - USA Paint Jobs Pack (304211) Depot
setManifestid(304211, "5999359468502785165", 0)
-- Euro Truck Simulator 2 - Scandinavia (AppID: 304212)
addappid(304212)
addappid(304212, 1, "e4eb05d826bd438b1cf3adbd187291b77b593745a3d9cb20a415c85cfc380bb6") -- Euro Truck Simulator 2 - Scandinavia - Euro Truck Simulator 2 - Scandinavia (304212) Depot
setManifestid(304212, "9182261033980732111", 180820867)
-- Euro Truck Simulator 2 - Canadian Paint Jobs Pack (AppID: 304213)
addappid(304213)
addappid(304213, 1, "faf0dd632893269bcc953ed6acba65f4cc31d09fbf7ba4d52c73e21bf5f5f5d2") -- Euro Truck Simulator 2 - Canadian Paint Jobs Pack - Euro Truck Simulator 2 - Canadian Paint Jobs Pack (304213) Depot
setManifestid(304213, "4371874931215817064", 0)
-- Euro Truck Simulator 2 - High Power Cargo Pack (AppID: 304214)
addappid(304214)
addappid(304214, 1, "884afba8823c2c7f29594929bea51b3b4d104c94d1eed509f7cbb74e6879a4b9") -- Euro Truck Simulator 2 - High Power Cargo Pack - Euro Truck Simulator 2 - High Power Cargo Pack (304214) Depot
setManifestid(304214, "5664607073299318301", 0)
-- Euro Truck Simulator 2 - German Paint Jobs Pack (AppID: 318500)
addappid(318500)
addappid(318500, 1, "d4684f2f1f482c5946d5ee03422739c055a78754c205f6817efe66c40a028bd0") -- Euro Truck Simulator 2 - German Paint Jobs Pack - Euro Truck Simulator 2 - German Paint Jobs Pack (318500) Depot
setManifestid(318500, "7202789966674546018", 0)
-- Euro Truck Simulator 2 - French Paint Jobs Pack (AppID: 318510)
addappid(318510)
addappid(318510, 1, "70f48e349fc6d019a92411b5390a3ca0ea301ced3b96a234ce62b843a9aaf5a2") -- Euro Truck Simulator 2 - French Paint Jobs Pack - Euro Truck Simulator 2 - French Paint Jobs Pack (318510) Depot
setManifestid(318510, "7992617693705249682", 0)
-- Euro Truck Simulator 2 - Czech Paint Jobs Pack (AppID: 318511)
addappid(318511)
addappid(318511, 1, "a2af29b1f466408287baa92fe53a054c5edee9ad5bbcbbd31c518a6af9664281") -- Euro Truck Simulator 2 - Czech Paint Jobs Pack - Euro Truck Simulator 2 - Czech Paint Jobs Pack (318511) Depot
setManifestid(318511, "4628475804235513753", 0)
-- Euro Truck Simulator 2 - Christmas Paint Jobs Pack (AppID: 318520)
addappid(318520)
addappid(318520, 1, "2c83753aedd232b4abaadc6192612fb42037a951ffd0c5a7704f6049f90e6fc0") -- Euro Truck Simulator 2 - Christmas Paint Jobs Pack - Euro Truck Simulator 2 - Christmas Paint Jobs Pack (318520) Depot
setManifestid(318520, "5568977514805005034", 0)
-- Euro Truck Simulator 2 - Raven Truck Design Pack (AppID: 318521)
addappid(318521)
addappid(318521, 1, "e86fdf8ee51e4b5f471c801c2685c034bf527852dd45e2b7875a1148bad09920") -- Euro Truck Simulator 2 - Raven Truck Design Pack - Euro Truck Simulator 2 - Raven Truck Design Pack (318521) Depot
setManifestid(318521, "483676476628106674", 0)
-- Euro Truck Simulator 2 - Norwegian Paint Jobs Pack (AppID: 347190)
addappid(347190)
addappid(347190, 1, "6e38118275d80be4547dbc47591536f9115b7371c9740190eb84e9b28ea2cf4a") -- Euro Truck Simulator 2 - Norwegian Paint Jobs Pack - Euro Truck Simulator 2 - Norwegian Paint Jobs Pack (347190) Depot
setManifestid(347190, "2376290245923035824", 0)
-- Euro Truck Simulator 2 - Danish Paint Jobs Pack (AppID: 347210)
addappid(347210)
addappid(347210, 1, "c6f97f2a29f4373af3f5f4288de1c7652edaf2ccdc83d19b0908abdb920699c7") -- Euro Truck Simulator 2 - Danish Paint Jobs Pack - Euro Truck Simulator 2 - Danish Paint Jobs Pack (347210) Depot
setManifestid(347210, "8538423298506949843", 0)
-- Euro Truck Simulator 2 - Swedish Paint Jobs Pack (AppID: 347211)
addappid(347211)
addappid(347211, 1, "3e727c3f2459b02345df4ba755343cc85e568f11e00d2921a6ae7a3eaaea80ea") -- Euro Truck Simulator 2 - Swedish Paint Jobs Pack - Euro Truck Simulator 2 - Swedish Paint Jobs Pack (347211) Depot
setManifestid(347211, "8493126685151868489", 0)
-- Euro Truck Simulator 2 - Viking Legends (AppID: 347212)
addappid(347212)
addappid(347212, 1, "d45d628eb639b8998835fd40634312e5b41366ab44f7041d4e712934c6687753") -- Euro Truck Simulator 2 - Viking Legends - Euro Truck Simulator 2 - Viking Legends (347212) Depot
setManifestid(347212, "280180584531605044", 0)
-- Euro Truck Simulator 2 - Russian Paint Jobs Pack (AppID: 347213)
addappid(347213)
addappid(347213, 1, "891169b29f28bd734fcd67f7711d95cbb9d6f8ebf9a9dfe0bbd257a4b0505ccb") -- Euro Truck Simulator 2 - Russian Paint Jobs Pack - Euro Truck Simulator 2 - Russian Paint Jobs Pack (347213) Depot
setManifestid(347213, "1648858371444446407", 0)
-- Euro Truck Simulator 2 - Cabin Accessories (AppID: 388470)
addappid(388470)
addappid(388470, 1, "a729fbd028cfa164dba072e2c6c9ee3c1766f0c59f99b4a208f3e8e3b87e2702") -- Euro Truck Simulator 2 - Cabin Accessories - Euro Truck Simulator 2 - Cabin Accessories (388470) Depot
setManifestid(388470, "4716220128845186726", 0)
-- Euro Truck Simulator 2 - Michelin Fan Pack (AppID: 388471)
addappid(388471)
addappid(388471, 1, "f3a39ad83fc8e32da3e0cb5795388a19c1b9ffa33408f14dbc6a8d00324f5d08") -- Euro Truck Simulator 2 - Michelin Fan Pack - Euro Truck Simulator 2 - Michelin Fan Pack (388471) Depot
setManifestid(388471, "763490717740367964", 0)
-- Euro Truck Simulator 2 - Japanese Paint Jobs Pack (AppID: 388472)
addappid(388472)
addappid(388472, 1, "aeb199820883929e63403f977bbc64a9074e190bc15e9c63c69c62b207828d8c") -- Euro Truck Simulator 2 - Japanese Paint Jobs Pack - Euro Truck Simulator 2 - Japanese Paint Jobs Pack (388472) Depot
setManifestid(388472, "5261877216088621057", 0)
-- Euro Truck Simulator 2 - Turkish Paint Jobs Pack (AppID: 388474)
addappid(388474)
addappid(388474, 1, "77991e467d4682641e5ce0cecec31522985864eb6fb73ed256452da4406a536e") -- Euro Truck Simulator 2 - Turkish Paint Jobs Pack - Euro Truck Simulator 2 - Turkish Paint Jobs Pack (388474) Depot
setManifestid(388474, "7023847166734251609", 0)
-- Euro Truck Simulator 2 - Wheel Tuning Pack (AppID: 388475)
addappid(388475)
addappid(388475, 1, "ab0619b51d856c6c0de489a9bb68bc90dd7719b154438352d22ca0d3cb19bcb1") -- Euro Truck Simulator 2 - Wheel Tuning Pack - Euro Truck Simulator 2 - Wheel Tuning Pack (388475) Depot
setManifestid(388475, "5508406148406286721", 0)
-- Euro Truck Simulator 2 - Italian Paint Jobs Pack (AppID: 388476)
addappid(388476)
addappid(388476, 1, "87711c8a894df742f5b3b2bef8de98b514577fd683c89d40d2341bcfef24ddef") -- Euro Truck Simulator 2 - Italian Paint Jobs Pack - Euro Truck Simulator 2 - Italian Paint Jobs Pack (388476) Depot
setManifestid(388476, "6769909265061195710", 0)
-- Euro Truck Simulator 2 - Schwarzmller Trailer Pack (AppID: 388477)
addappid(388477)
addappid(388477, 1, "68c0c97eb4e09492c0a3e486fb76265f9e16869ccbb5dda4bf6d4025d075724c") -- Euro Truck Simulator 2 - Schwarzmller Trailer Pack - Euro Truck Simulator 2 - Schwarzmüller Trailer Pack (388477) Depot
setManifestid(388477, "318719124303882667", 0)
-- Euro Truck Simulator 2 - Hungarian Paint Jobs Pack (AppID: 388479)
addappid(388479)
addappid(388479, 1, "dbe25d6a318f8f1c1596ed31f20e1b46d80d8a8c6bd6132d1de4aacee59e3c4f") -- Euro Truck Simulator 2 - Hungarian Paint Jobs Pack - Euro Truck Simulator 2 - Hungarian Paint Jobs Pack (388479) Depot
setManifestid(388479, "8043778932844749102", 0)
-- Euro Truck Simulator 2 - Slovak Paint Jobs Pack (AppID: 461240)
addappid(461240)
addappid(461240, 1, "fa0637146d19b8b2d950139cf43a17d6e9cb310e1890e6b51bbd8c0dd7a86667") -- Euro Truck Simulator 2 - Slovak Paint Jobs Pack - Euro Truck Simulator 2 - Slovak Paint Jobs Pack (461240) Depot
setManifestid(461240, "7432566952650997396", 0)
-- Euro Truck Simulator 2 - Spanish Paint Jobs Pack (AppID: 461241)
addappid(461241)
addappid(461241, 1, "7646ba3063910ff501e7eaf351220bbca90e90966948eab097163537b4b4094e") -- Euro Truck Simulator 2 - Spanish Paint Jobs Pack - Euro Truck Simulator 2 - Spanish Paint Jobs Pack (461241) Depot
setManifestid(461241, "4905364748903397876", 0)
-- Euro Truck Simulator 2 - Window Flags (AppID: 461242)
addappid(461242)
addappid(461242, 1, "55b64424abcb936aa720b487af255b65658fb43250fda2182e3e9a78db56eeae") -- Euro Truck Simulator 2 - Window Flags - Euro Truck Simulator 2 - National Window Flags (461242) Depot
setManifestid(461242, "5400260333145696346", 0)
-- Euro Truck Simulator 2 - Austrian Paint Jobs Pack (AppID: 461243)
addappid(461243)
addappid(461243, 1, "ec1615229bc77d971fe9d99fddb9ea4208b87edad45b7d374724592b13409b73") -- Euro Truck Simulator 2 - Austrian Paint Jobs Pack - Euro Truck Simulator 2 - Austrian Paint Jobs Pack (461243) Depot
setManifestid(461243, "7217290017793550202", 0)
-- Euro Truck Simulator 2 - Mighty Griffin Tuning Pack (AppID: 461244)
addappid(461244)
addappid(461244, 1, "5179b4667e35b10483b6e4d6e920cae7aa1466119c369d60f817daf39a182b6b") -- Euro Truck Simulator 2 - Mighty Griffin Tuning Pack - Euro Truck Simulator 2 - Mighty Griffin Tuning Pack (461244) Depot
setManifestid(461244, "8722492570923931470", 0)
-- Euro Truck Simulator 2 - South Korean Paint Jobs Pack (AppID: 461245)
addappid(461245)
addappid(461245, 1, "d8594320bae45917c8c163c392d336c6b2434a7864476f0a362522a401769aeb") -- Euro Truck Simulator 2 - South Korean Paint Jobs Pack - Euro Truck Simulator 2 - South Korean Paint Jobs Pack (461245) Depot
setManifestid(461245, "627390679225060384", 0)
-- Euro Truck Simulator 2 - Swiss Paint Jobs Pack (AppID: 461246)
addappid(461246)
addappid(461246, 1, "478e411d19999bd79bb97f6bdfd26bcde124255f77758980b6b1eb5b941ebee3") -- Euro Truck Simulator 2 - Swiss Paint Jobs Pack - Euro Truck Simulator 2 - Swiss Paint Jobs Pack (461246) Depot
setManifestid(461246, "6215803422112305490", 0)
-- Euro Truck Simulator 2 - Chinese Paint Jobs Pack (AppID: 461247)
addappid(461247)
addappid(461247, 1, "85e8e82506156b32a06db9dcc41e42060f78434b047c7ce8e24b9757efe117fd") -- Euro Truck Simulator 2 - Chinese Paint Jobs Pack - Euro Truck Simulator 2 - Chinese Paint Jobs Pack (461247) Depot
setManifestid(461247, "2564821458389052219", 0)
-- Euro Truck Simulator 2 - Pirate Paint Jobs Pack (AppID: 461248)
addappid(461248)
addappid(461248, 1, "170a233de5371a3103a336b9e16c8af6af2231301cbe72d3c95defa393526e62") -- Euro Truck Simulator 2 - Pirate Paint Jobs Pack - Euro Truck Simulator 2 - Pirate Paint Jobs Pack (461248) Depot
setManifestid(461248, "9211433779081099616", 0)
-- Euro Truck Simulator 2 - XF Tuning Pack (AppID: 461249)
addappid(461249)
addappid(461249, 1, "1d99a3412d2a4c03edeeeb15e8a0a8058556a2982f93ea3d90ded2a92c289dce") -- Euro Truck Simulator 2 - XF Tuning Pack - Euro Truck Simulator 2 - XF Tuning Pack (461249) Depot
setManifestid(461249, "1714236825747095403", 0)
-- Euro Truck Simulator 2 - Lunar New Year Pack (AppID: 526950)
addappid(526950)
addappid(526950, 1, "cc767e163423b6b03dc66f7c695212b4deb1978c89bb0000a4427db2a39bcf0d") -- Euro Truck Simulator 2 - Lunar New Year Pack - Euro Truck Simulator 2 - Lunar New Year Pack (526950) Depot
setManifestid(526950, "2333631855110248746", 0)
-- Euro Truck Simulator 2 - Vive la France  (AppID: 531130)
addappid(531130)
addappid(531130, 1, "2009ea02e74e2e3438c16df3475863ac4fea7a409bef60a339fad9781f1b3185") -- Euro Truck Simulator 2 - Vive la France  - Euro Truck Simulator 2 - Vive la France ! (531130) Depot
setManifestid(531130, "4389226223857687358", 94878151)
-- Euro Truck Simulator 2 - Heavy Cargo Pack (AppID: 531131)
addappid(531131)
addappid(531131, 1, "3cac01adc92d11de7a91d5e413a3762670847261f8cf7bb131faec3ba9b99db3") -- Euro Truck Simulator 2 - Heavy Cargo Pack - Euro Truck Simulator 2 - Heavy Cargo Pack (531131) Depot
setManifestid(531131, "620015009428909093", 0)
-- Euro Truck Simulator 2 - Finnish Paint Jobs Pack (AppID: 540720)
addappid(540720)
addappid(540720, 1, "b3f6c3fbc60c3b5ebafb8b7d8f80a3b1985e8958f41920fd4f12777d266a90f5") -- Euro Truck Simulator 2 - Finnish Paint Jobs Pack - Euro Truck Simulator 2 - Finnish Paint Jobs Pack (540720) Depot
setManifestid(540720, "1646764676298902558", 0)
-- Euro Truck Simulator 2 - Belgian Paint Jobs Pack (AppID: 540721)
addappid(540721)
addappid(540721, 1, "273635bd103f2ca132ec8ca31f65b805ee59b498741edeea4a037d62edb1f9e4") -- Euro Truck Simulator 2 - Belgian Paint Jobs Pack - Euro Truck Simulator 2 - Belgian Paint Job Pack (540721) Depot
setManifestid(540721, "5995400305895737089", 0)
-- Euro Truck Simulator 2 - Dragon Truck Design Pack (AppID: 558240)
addappid(558240)
addtoken(558240, "7693758108019961089")
addappid(558240, 1, "998330b0c6bf49c43a810186d568047bce0cca54226dec5195eaef5f1e06d997") -- Euro Truck Simulator 2 - Dragon Truck Design Pack - Euro Truck Simulator 2 - Dragon Truck Design Pack (558240) Depot
setManifestid(558240, "702960128756830977", 0)
-- Euro Truck Simulator 2 - Romanian Paint Jobs Pack (AppID: 558241)
addappid(558241)
addappid(558241, 1, "3f1d8d6a37ec6ac17285059ac7ffceaac561e83b78c5e3f8c19159393a0fcb1c") -- Euro Truck Simulator 2 - Romanian Paint Jobs Pack - Euro Truck Simulator 2 - Romanian Paint Jobs Pack(558241) Depot
setManifestid(558241, "7516040781686027632", 0)
-- Euro Truck Simulator 2 - Australian Paint Jobs Pack (AppID: 558242)
addappid(558242)
addappid(558242, 1, "7748a8e37c27b371b7692d2ad50f4d210e8c3bb6683047a4b97774c89bfd247c") -- Euro Truck Simulator 2 - Australian Paint Jobs Pack - Euro Truck Simulator 2 - Australian Paint Jobs Pack (558242) Depot
setManifestid(558242, "5361107034067998893", 0)
-- Euro Truck Simulator 2 - Valentines Paint Jobs Pack (AppID: 558243)
addappid(558243)
addappid(558243, 1, "84f20ef511071ab8920d5d2a1396660e156023cfa9dbb74ab956dbc58fbeba8e") -- Euro Truck Simulator 2 - Valentines Paint Jobs Pack - Euro Truck Simulator 2 - Valentine's Paint Jobs Pack (558243) Depot
setManifestid(558243, "7485045655295992031", 0)
-- Euro Truck Simulator 2 - Italia (AppID: 558244)
addappid(558244)
addappid(558244, 1, "9719afc41fd0ac583693e96fb57d47629e70b466ed8e1ba653f9e584741551ff") -- Euro Truck Simulator 2 - Italia - Euro Truck Simulator 2 - Italia (558244) Depot
setManifestid(558244, "8673956512356728916", 84239992)
-- Euro Truck Simulator 2 - Special Transport (AppID: 558245)
addappid(558245)
addappid(558245, 1, "78a96462ea125cfa8fcc98f7832146f9e1e8a3205a57b18773cd243b535f47ce") -- Euro Truck Simulator 2 - Special Transport - Euro Truck Simulator 2 - Special Transport (558245) Depot
setManifestid(558245, "553771190614744972", 0)
-- Euro Truck Simulator 2 - Portuguese Paint Jobs Pack (AppID: 876980)
addappid(876980)
addappid(876980, 1, "cf85cedf09ec405f21338fce1cf9efa360710fd5be02c97420b2534d871680bd") -- Euro Truck Simulator 2 - Portuguese Paint Jobs Pack - Euro Truck Simulator 2 - Portuguese Paint Jobs Pack (876980) Depot
setManifestid(876980, "6406937035159279794", 0)
-- Euro Truck Simulator 2 - Dutch Paint Jobs Pack (AppID: 909640)
addappid(909640)
addappid(909640, 1, "93a0622d37996d65d3ebccfe109847c6be9118dcb5f980bb5d317d29c89f4616") -- Euro Truck Simulator 2 - Dutch Paint Jobs Pack - Euro Truck Simulator 2 - Dutch Paint Jobs Pack (909640) Depot
setManifestid(909640, "1919550032765055462", 0)
-- Euro Truck Simulator 2 - Beyond the Baltic Sea (AppID: 925580)
addappid(925580)
addappid(925580, 1, "aec0bb982622c145e437172016f65040db8b8d005d7de9ddff758f292f035ab1") -- Euro Truck Simulator 2 - Beyond the Baltic Sea - Euro Truck Simulator 2 - Beyond the Baltic Sea (925580) Depot
setManifestid(925580, "5875445065205272269", 100645748)
-- Euro Truck Simulator 2 - Space Paint Jobs Pack (AppID: 925650)
addappid(925650)
addappid(925650, 1, "754a3ef9021990cf28a11008df0387fb87e9b799e83ad10090edc69bf0bbc276") -- Euro Truck Simulator 2 - Space Paint Jobs Pack - Euro Truck Simulator 2 - Space Paint Jobs Pack (925650) Depot
setManifestid(925650, "4945826575397812199", 0)
-- Euro Truck Simulator 2 - Krone Trailer Pack (AppID: 933610)
addappid(933610)
addappid(933610, 1, "ddec5ac79ef43babb022170583cf8dde89b8806caccfca75ead38d8adf53ee3f") -- Euro Truck Simulator 2 - Krone Trailer Pack - Euro Truck Simulator 2 - Krone Trailer Pack (933610) Depot
setManifestid(933610, "5991883449228130297", 0)
-- Euro Truck Simulator 2 - Estonian Paint Jobs Pack (AppID: 980590)
addappid(980590)
addappid(980590, 1, "e94dd3368f57beea8e661d243f7106b88befdd6e6f448810fa65a00de6a2300f") -- Euro Truck Simulator 2 - Estonian Paint Jobs Pack - Euro Truck Simulator 2 - Estonian Paint Jobs Pack (980590) Depot
setManifestid(980590, "3465626021269207986", 0)
-- Euro Truck Simulator 2 - Latvian Paint Jobs Pack (AppID: 980591)
addappid(980591)
addappid(980591, 1, "5f01151bee644c449f49705841a63539f3c18cface0c0475f004a8d766595ebf") -- Euro Truck Simulator 2 - Latvian Paint Jobs Pack - Euro Truck Simulator 2 - Latvian Paint Jobs Pack (980591) Depot
setManifestid(980591, "7545485906113247155", 0)
-- Euro Truck Simulator 2 - Lithuanian Paint Jobs Pack (AppID: 980592)
addappid(980592)
addappid(980592, 1, "6938e01c6c62fc7cf4492da3d71ae843704d183710e00f3f5b853dc6facd4d42") -- Euro Truck Simulator 2 - Lithuanian Paint Jobs Pack - Euro Truck Simulator 2 - Lithuanian Paint Jobs Pack (980592) Depot
setManifestid(980592, "3931725649050572730", 0)
-- Euro Truck Simulator 2 - Road to the Black Sea (AppID: 1056760)
addappid(1056760)
addappid(1056760, 1, "1e46ab2ee8de2d7e67a7c961d64814862e8323729f0be7deeb7f9ac75820e83e") -- Euro Truck Simulator 2 - Road to the Black Sea - Euro Truck Simulator 2 -  Road to the Black Sea (1056760) Depot
setManifestid(1056760, "5474745325550270163", 209266925)
-- Euro Truck Simulator 2 - Actros Tuning Pack (AppID: 1056761)
addappid(1056761)
addappid(1056761, 1, "0407379a627760ba025f05a1d3ea50ce1bb0dfc7b8491b768b688b225e05e2c4") -- Euro Truck Simulator 2 - Actros Tuning Pack - Euro Truck Simulator 2 - Actros Tuning Pack (1056761) Depot
setManifestid(1056761, "4671341810091804714", 0)
-- Euro Truck Simulator 2 - Pink Ribbon Charity Pack (AppID: 1068290)
addappid(1068290)
addappid(1068290, 1, "1107c219b4ea21a4ac372e06a6a62dec61bcd18479e1ac038b0a6ad52cb6a3c8") -- Euro Truck Simulator 2 - Pink Ribbon Charity Pack - Euro Truck Simulator 2 - Pink Ribbon Pack (1068290) Depot
setManifestid(1068290, "1067637122708666818", 0)
-- Euro Truck Simulator 2 - Goodyear Tyres Pack (AppID: 1117140)
addappid(1117140)
addappid(1117140, 1, "416b302255b34e7a36475012121166f0bdeeabec65ad6819ac2f7f36535d041f") -- Euro Truck Simulator 2 - Goodyear Tyres Pack - Euro Truck Simulator 2 - Goodyear Tyres Pack (1117140) Depot
setManifestid(1117140, "7178260226727326542", 0)
-- Euro Truck Simulator 2 - Bulgarian Paint Jobs Pack (AppID: 1159030)
addappid(1159030)
addappid(1159030, 1, "7817bf09d17d1f4323c498b4dfba69731fe237a79c1880d2d5d5ffa631795084") -- Euro Truck Simulator 2 - Bulgarian Paint Jobs Pack - Euro Truck Simulator 2 - Bulgarian Paint Jobs Pack (1159030) Depot
setManifestid(1159030, "1121503996381158582", 0)
-- Euro Truck Simulator 2 - Iberia (AppID: 1209460)
addappid(1209460)
addappid(1209460, 1, "f0e1ecc5f7ea5b844363c51ecf8ba76ab4f0166bbbb36f93e51a45134426a924") -- Euro Truck Simulator 2 - Iberia - Euro Truck Simulator 2 - Iberia (1209460) Depot
setManifestid(1209460, "2167681639159167088", 344226238)
-- Euro Truck Simulator 2 - HS-Schoch Tuning Pack (AppID: 1209461)
addappid(1209461)
addappid(1209461, 1, "b7f8219f8fed4e94ff74b2b35e16da761eea7fd3e9ef505d77a90e4208cd050a") -- Euro Truck Simulator 2 - HS-Schoch Tuning Pack - Euro Truck Simulator 2 - HS-Schoch Tuning Pack (1209461) Depot
setManifestid(1209461, "3324815250320656782", 0)
-- Euro Truck Simulator 2 - FH Tuning Pack (AppID: 1299530)
addappid(1299530)
addappid(1299530, 1, "b2782485e3ba8e8c186d72a545cc77af9a7f535768efd8f7be77f8486ac1e6fa") -- Euro Truck Simulator 2 - FH Tuning Pack - Euro Truck Simulator 2 - FH Tuning Pack (1299530) Depot
setManifestid(1299530, "2379835362999603702", 0)
-- Euro Truck Simulator 2 - Super Stripes Paint Jobs Pack (AppID: 1415700)
addappid(1415700)
addappid(1415700, 1, "4e2401eead464d941dad26b180105b715e5d5116066c00176789f32001b6ad59") -- Euro Truck Simulator 2 - Super Stripes Paint Jobs Pack - Euro Truck Simulator 2 - Super Stripes Paint Jobs Pack (1415700) Depot
setManifestid(1415700, "4489366073136472613", 0)
-- Euro Truck Simulator 2 - Farm Machinery (AppID: 1456860)
addappid(1456860)
addappid(1456860, 1, "d686ee647b9eb5e7fcd89fd7c82e7b0d201e7ca7402129d7e2de233b8bffcf8e") -- Euro Truck Simulator 2 - Farm Machinery - Depot 1456860
setManifestid(1456860, "8627600342676627930", 0)
-- Euro Truck Simulator 2 - DAF XGXG (AppID: 1650650)
addappid(1650650)
addappid(1650650, 1, "18a31f4193d242da5acc55e09f2959070cfe4a0260c63766f4b90962382a4f26") -- Euro Truck Simulator 2 - DAF XGXG - Euro Truck Simulator 2 - DAF XG/XG+ (1650650) Depot
setManifestid(1650650, "1383614172783786394", 0)
-- Euro Truck Simulator 2 - Volvo Construction Equipment (AppID: 1704460)
addappid(1704460)
addappid(1704460, 1, "38c81d058e71a846f9021921aa37ddd348f9af87fd48670737deef33385cc2f9") -- Euro Truck Simulator 2 - Volvo Construction Equipment - Depot 1704460
setManifestid(1704460, "8323549460675734992", 0)
-- Euro Truck Simulator 2 - Ukrainian Paint Jobs Pack (AppID: 1918370)
addappid(1918370)
addappid(1918370, 1, "33151097e4f013798a168cca80b589372225a7ac4c36f618632464a0f38629d2") -- Euro Truck Simulator 2 - Ukrainian Paint Jobs Pack - Depot 1918370
setManifestid(1918370, "6888770779331421318", 0)
-- Euro Truck Simulator 2 - Renault Trucks T Tuning Pack (AppID: 1967640)
addappid(1967640)
addappid(1967640, 1, "12ad16eb6961ac01cbbb168c905eef4913188ee2ff7ee94083de1399ea9a1b08") -- Euro Truck Simulator 2 - Renault Trucks T Tuning Pack - Depot 1967640
setManifestid(1967640, "8368596210107716972", 0)
-- Euro Truck Simulator 2 - Street Art Paint Jobs Pack (AppID: 1967650)
addappid(1967650)
addappid(1967650, 1, "8ef5c45e8e7037babf87a4985e6dbff0963fe9fbce85cea103fec9e58701335d") -- Euro Truck Simulator 2 - Street Art Paint Jobs Pack - Depot 1967650
setManifestid(1967650, "8615273824501394788", 0)
-- Euro Truck Simulator 2 - West Balkans (AppID: 2004210)
addappid(2004210)
addappid(2004210, 1, "c9d6379e66ca8737ffb17de5f52a289094a0fef253746a049d15576d849d6235") -- Euro Truck Simulator 2 - West Balkans - Depot 2004210
setManifestid(2004210, "4167568693084506900", 428988861)
-- Euro Truck Simulator 2 - Feldbinder Trailer Pack (AppID: 2193220)
addappid(2193220)
addappid(2193220, 1, "b215faf14c32591707fbef62e913ce317843165ca9b2927ccd681a0509c2b817") -- Euro Truck Simulator 2 - Feldbinder Trailer Pack - Depot 2193220
setManifestid(2193220, "3225902090318410395", 0)
-- Euro Truck Simulator 2 - MAN TGX (AppID: 2371170)
addappid(2371170)
addappid(2371170, 1, "1fcd77106389d142c555008bba4ce9bff600547c679de34c5193180067dbc949") -- Euro Truck Simulator 2 - MAN TGX - Depot 2371170
setManifestid(2371170, "7809383020142126541", 0)
-- Euro Truck Simulator 2 - Wielton Trailer Pack (AppID: 2455690)
addappid(2455690)
addappid(2455690, 1, "aaca7608313f96a5a2ce8adc1e5ad98340690c6f2ed4c506d4efc67be45c2f31") -- Euro Truck Simulator 2 - Wielton Trailer Pack - Depot 2455690
setManifestid(2455690, "7895863578875893287", 0)
-- Euro Truck Simulator 2 - Tirsan Trailer Pack (AppID: 2569750)
addappid(2569750)
addappid(2569750, 1, "27584c1ad2058a5cc6660a7728f2a7d7901d9ed31f8f6fe15d4500aac2554d32") -- Euro Truck Simulator 2 - Tirsan Trailer Pack - Depot 2569750
setManifestid(2569750, "7245421719166789535", 0)
-- Euro Truck Simulator 2 - Modern Lines Paint Jobs Pack (AppID: 2579670)
addappid(2579670)
addappid(2579670, 1, "ef02b23e6509e898231b08901860784e12be5be0480fec8e271171d7c79c1528") -- Euro Truck Simulator 2 - Modern Lines Paint Jobs Pack - Depot 2579670
setManifestid(2579670, "8804192099694682025", 0)
-- Euro Truck Simulator 2 - Greece (AppID: 2604420)
addappid(2604420)
addappid(2604420, 1, "322d1b2e394c5b4a188fffc43809b8f8c4bb9c260e14a27c24ea217a4cb26a0c") -- Euro Truck Simulator 2 - Greece - Depot 2604420
setManifestid(2604420, "708575501480919059", 498300378)
-- Euro Truck Simulator 2 - DAF XD (AppID: 2611740)
addappid(2611740)
addappid(2611740, 1, "72f023418f51891b17a771cd733b110c092a6a17d8dddbecc476f0fdc506fcfd") -- Euro Truck Simulator 2 - DAF XD - Depot 2611740
setManifestid(2611740, "5009768597697504470", 0)
-- Euro Truck Simulator 2 - JCB Equipment Pack (AppID: 2780800)
addappid(2780800)
addappid(2780800, 1, "3e7a55f4a90a70ff249cbab7994485d13859bfb8922f22265b09b21f4b25b19c") -- Euro Truck Simulator 2 - JCB Equipment Pack - Depot 2780800
setManifestid(2780800, "6125692916729941617", 0)
-- Euro Truck Simulator 2 - Nordic Horizons (AppID: 2780810)
addappid(2780810)
addappid(2780810, 1, "c68b6cdbf16729474fb886f2a7d3a77f113ed7d4f606b0001144a95591035627") -- Euro Truck Simulator 2 - Nordic Horizons - Depot 2780810
setManifestid(2780810, "1232669252224309913", 570163383)
-- Euro Truck Simulator 2 - Schmitz Cargobull Trailer Pack (AppID: 2833100)
addappid(2833100)
addappid(2833100, 1, "c4a281a6503a6911a8ed7f583a3bcfcd95738ed8f9302533c3fc53a24199ed5e") -- Euro Truck Simulator 2 - Schmitz Cargobull Trailer Pack - Depot 2833100
setManifestid(2833100, "8987986584070519860", 0)
-- Euro Truck Simulator 2 - Renault Trucks E-Tech T (AppID: 2932420)
addappid(2932420)
addappid(2932420, 1, "1bb65d2da60e4acf76f3539c02dc2a89ca727e99a4276f7c7dc3084abe451f46") -- Euro Truck Simulator 2 - Renault Trucks E-Tech T - Depot 2932420
setManifestid(2932420, "8290080232077515320", 0)
-- Euro Truck Simulator 2 - Kgel Trailer Pack (AppID: 3034940)
addappid(3034940)
addappid(3034940, 1, "6169b53b430db7a91db51a83ed73aa01c33f330c9f34ce1c67742a678b43b561") -- Euro Truck Simulator 2 - Kgel Trailer Pack - Depot 3034940
setManifestid(3034940, "6024978619739322674", 0)
-- Euro Truck Simulator 2 - Kssbohrer Trailer Pack (AppID: 3034950)
addappid(3034950)
addappid(3034950, 1, "97726a24a42f14c92d1be5d998742e20c7dfaebe3c517719c0406100e472dbc1") -- Euro Truck Simulator 2 - Kssbohrer Trailer Pack - Depot 3034950
setManifestid(3034950, "3942582452463801047", 0)
-- Euro Truck Simulator 2 - Scania S BEV (AppID: 3035040)
addappid(3035040)
addappid(3035040, 1, "265987b6be428d11dfc1ce48fabe6cd08e1382d83f8f4fea2b873f5bf04413cc") -- Euro Truck Simulator 2 - Scania S BEV - Depot 3035040
setManifestid(3035040, "6665593843249505581", 0)
-- Euro Truck Simulator 2 - Volvo FH Series 5 (AppID: 3323350)
addappid(3323350)
addappid(3323350, 1, "f052b8b9da688d69eb6b7d9162ddf68fb0caa23dcb84a22cbf5f4125399db031") -- Euro Truck Simulator 2 - Volvo FH Series 5 - Depot 3323350
setManifestid(3323350, "8695049842862174770", 0)
-- Euro Truck Simulator 2 - Volvo FH Series 6 (AppID: 3323360)
addappid(3323360)
addappid(3323360, 1, "3759b4df13b1da02928e0a58473807f4ddc07f9b1f3513dff867458136e36715") -- Euro Truck Simulator 2 - Volvo FH Series 6 - Depot 3323360
setManifestid(3323360, "6312086033646729789", 0)
-- Euro Truck Simulator 2 - Greek Mythology Pack (AppID: 3335300)
addappid(3335300)
addappid(3335300, 1, "2a256b173394ae795423eeb99d57400944ea92248ee22379541c4f63b5e5273c") -- Euro Truck Simulator 2 - Greek Mythology Pack - Depot 3335300
setManifestid(3335300, "5730712882518993272", 0)
-- Euro Truck Simulator 2 - Iveco S-Way (AppID: 3354860)
addappid(3354860)
addappid(3354860, 1, "7ab4299e2db99a337ec4ecbda76dcd0530766e8c3790e8a0419e98f8847fa833") -- Euro Truck Simulator 2 - Iveco S-Way - Depot 3354860
setManifestid(3354860, "6789632481762577527", 0)
-- Euro Truck Simulator 2 - KRONE Agriculture Equipment (AppID: 3872920)
addappid(3872920)
addappid(3872920, 1, "b8e6dce270a9c23586386a0b33b8815e9ca3dfaf0c0061353832ef483047ea1e") -- Euro Truck Simulator 2 - KRONE Agriculture Equipment - Depot 3872920
setManifestid(3872920, "1123451156927013286", 0)
-- Euro Truck Simulator 2 - DAF XF Electric (AppID: 3977520)
addappid(3977520)
addappid(3977520, 1, "7aaa899d41f514cf7cb89c490327d090fd2b07fb94d058ead93b4656b71bb09b") -- Euro Truck Simulator 2 - DAF XF Electric - Depot 3977520
setManifestid(3977520, "7408828465166967332", 0)
-- Euro Truck Simulator 2 - Forest Machinery (AppID: 4159240)
addappid(4159240)
addappid(4159240, 1, "904248995cb6ad9e37ff4571f34b9b6a7f9ad213b63aed13fda017cd070c8bc0") -- Euro Truck Simulator 2 - Forest Machinery - Depot 4159240
setManifestid(4159240, "2587848077194228934", 0)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(1536500) -- Euro Truck Simulator 2 - Heart of Russia (unreleased)
-- addappid(3796990) -- Euro Truck Simulator 2 - Iceland (unreleased)
-- addappid(3809270) -- Euro Truck Simulator 2 - Coaches (unreleased)
-- addappid(3851260) -- Euro Truck Simulator 2 - Isle of Ireland (unreleased)